import "./index.css";
import foto from "./assets/perfil.jpeg";
import certificado1 from "./assets/certificado1.png";
import certificado2 from "./assets/certificado2.png";
import certificado3 from "./assets/certificado3.png";

function App() {
  return (
    <>
      {/* NAVBAR */}
      <nav className="navbar">
        <h2>Angui Fierro</h2>

        <div className="nav-links">
          <a href="#sobre">Sobre mí</a>
          <a href="#skills">Skills</a>
          <a href="#certificados">Certificados</a>
          <a href="#proyectos">Proyectos</a>
          <a href="#contacto">Contacto</a>
        </div>
      </nav>

      {/* HERO */}
      <section className="hero">
        <div className="hero-image">
          <img src={foto} alt="Angui Fierro" />
        </div>

        <div className="hero-content">
          <span className="badge">
            👩‍💻 Estudiante de Desarrollo de Software
          </span>

          <h1>Angui Fierro</h1>

          <h3>React • Java • Python • C++ • Cisco</h3>

          <p>
            Soy estudiante universitaria apasionada por la tecnología,
            el desarrollo web, la programación orientada a objetos,
            las bases de datos y la creación de soluciones innovadoras.
          </p>

          <div className="hero-buttons">
            <button>Ver Proyectos</button>
            <button>Descargar CV</button>
          </div>
        </div>
      </section>

      {/* PERFIL PROFESIONAL */}
      <section className="section">
        <h2>Perfil Profesional</h2>

        <p>
          Estudiante de Desarrollo de Software con conocimientos en
          desarrollo web, programación orientada a objetos,
          estructuras de datos, bases de datos, redes y desarrollo
          de aplicaciones. Me caracterizo por la responsabilidad,
          la disciplina y el aprendizaje continuo.
        </p>
      </section>

      {/* SOBRE MI */}
      <section id="sobre" className="section gray">
        <h2>Sobre Mí</h2>

        <div className="cards">
          <div className="card">
            <h3>🎓 Formación</h3>

            <p>
              Estudiante de Desarrollo de Software en la
              Escuela Politécnica Nacional.
            </p>
          </div>

          <div className="card">
            <h3>💻 Programación</h3>

            <p>
              Experiencia académica en Java, Python,
              React, JavaFX y C++.
            </p>
          </div>

          <div className="card">
            <h3>🚀 Objetivo</h3>

            <p>
              Convertirme en desarrolladora Full Stack
              y participar en proyectos innovadores.
            </p>
          </div>
        </div>
      </section>

      {/* HABILIDADES */}
      <section id="skills" className="section">
        <h2>Habilidades Técnicas</h2>

        <div className="cards">
          <div className="card">⚛️ React</div>
          <div className="card">☕ Java</div>
          <div className="card">🐍 Python</div>
          <div className="card">💻 C++</div>
          <div className="card">🌐 Cisco</div>
          <div className="card">🗄️ MySQL</div>
          <div className="card">🎨 HTML/CSS</div>
          <div className="card">🐙 GitHub</div>
        </div>
      </section>

      {/* CERTIFICADOS */}
      <section id="certificados" className="section gray">
        <h2>Certificaciones</h2>

        <div className="certificados">
          <div className="certificado-card">
            <img src={certificado1} alt="Certificado Programación" />

            <h3>Introducción a la Programación</h3>

            <p>
              Fundamentos de programación, lógica computacional
              y resolución de problemas.
            </p>
          </div>

          <div className="certificado-card">
            <img src={certificado2} alt="Certificado Front End" />

            <h3>Desarrollador Front-End</h3>

            <p>
              Desarrollo de interfaces modernas utilizando
              HTML, CSS y JavaScript.
            </p>
          </div>

          <div className="certificado-card">
            <img src={certificado3} alt="Certificado Web Development" />

            <h3>Web Development</h3>

            <p>
              Desarrollo y mantenimiento de sitios web
              y aplicaciones modernas.
            </p>
          </div>
        </div>
      </section>

      {/* PROYECTOS */}
      <section id="proyectos" className="section">
        <h2>Proyectos Destacados</h2>

        <div className="cards">
          <div className="card">
            <h3>POLITOUR</h3>

            <p>
              Sistema inteligente de rutas turísticas
              utilizando grafos y algoritmo de Dijkstra.
            </p>
          </div>

          <div className="card">
            <h3>Clínica JavaFX</h3>

            <p>
              Gestión de pacientes, médicos y citas médicas.
            </p>
          </div>

          <div className="card">
            <h3>Tienda Virtual</h3>

            <p>
              Sistema de autenticación y administración
              de usuarios.
            </p>
          </div>
        </div>
      </section>

      {/* FORMACIÓN */}
      <section className="section gray">
        <h2>Formación Académica</h2>

        <div className="cards">
          <div className="card">
            <h3>🎓 Escuela Politécnica Nacional</h3>

            <p>
              Tecnología Superior en Desarrollo de Software
            </p>

            <p>
              2023 - Actualidad
            </p>
          </div>
        </div>
      </section>

      {/* IDIOMAS */}
      <section className="section">
        <h2>Idiomas</h2>

        <div className="cards">
          <div className="card">
            🇪🇨 Español - Nativo
          </div>

          <div className="card">
            🇺🇸 Inglés - Intermedio
          </div>
        </div>
      </section>

      {/* OBJETIVOS */}
      <section className="section gray">
        <h2>Objetivos Profesionales</h2>

        <p>
          Mi objetivo es desarrollarme como profesional
          del software, fortalecer mis habilidades Full Stack
          y participar en proyectos innovadores.
        </p>
      </section>

      {/* CONTACTO */}
      <section id="contacto" className="section">
        <h2>Contacto</h2>

        <div className="cards">
          <div className="card">
            <h3>📧 Correo</h3>
            <p>
              anguifierro56@gmail.com
            </p>
          </div>

          <div className="card">
            <h3>💻 GitHub</h3>
            <p>
              github.com/tuusuario
            </p>
          </div>

          <div className="card">
            <h3>🔗 LinkedIn</h3>
            <p>
              linkedin.com/in/tuusuario
            </p>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer>
        <h3>Angui Fierro</h3>

        <p>
          Estudiante de Desarrollo de Software
        </p>

        <p>
          React • Java • Python • C++ • Cisco
        </p>

        <br />

        <p>
          © 2026 Todos los derechos reservados
        </p>
      </footer>
    </>
  );
}

export default App;