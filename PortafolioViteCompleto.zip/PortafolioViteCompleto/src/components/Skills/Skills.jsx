import "./Skills.css";

export function Skills() {
  return (
    <section className="skills">

      <h2>Habilidades</h2>

      <div className="skills-grid">

        <div className="skill">React</div>
        <div className="skill">Java</div>
        <div className="skill">Python</div>
        <div className="skill">C++</div>
        <div className="skill">Cisco</div>
        <div className="skill">MySQL</div>

      </div>

    </section>
  );
}