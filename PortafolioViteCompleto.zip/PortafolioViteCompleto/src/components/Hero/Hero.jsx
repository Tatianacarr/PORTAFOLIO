import "./Hero.css";
import foto from "./assets/perfil.jpg";

<nav className="navbar">

  <h2>Angui Fierro</h2>

  <div>
    <a href="#sobre">Sobre Mí</a>
    <a href="#skills">Skills</a>
    <a href="#proyectos">Proyectos</a>
    <a href="#contacto">Contacto</a>
  </div>

</nav>
function Hero() {
  return (
    <section className="hero">
      <div className="hero__img">
        <img src={foto} alt="perfil" />
      </div>

      <div className="hero__content">
        <h1>Angui Fierro</h1>

        <h2>Estudiante de Desarrollo de Software</h2>

        <p>
          Apasionada por el desarrollo web, Java,
          Python, React, C++ y Redes Cisco.
        </p>
      </div>
    </section>
  );
}

export default Hero;